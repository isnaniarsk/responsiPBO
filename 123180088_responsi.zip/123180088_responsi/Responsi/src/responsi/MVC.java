/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

/**
 *
 * @author ASUS
 */
public class MVC {
   
    public void Gaji(){
            View_Pegawai viewPegawai = new View_Pegawai();
            Model model = new Model();
            Controller controller = new Controller(viewPegawai,model);
        }
    
    public void Data(){
            View_Data viewData = new View_Data();
            Model model = new Model();
        }
    
}
