/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

/**
 *
 * @author ASUS
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
public class View_Data extends JFrame{
    JTable tabel;
    DefaultTableModel tableModel;
    JScrollPane scrollPane;
    Object namaKolom[] = {"ID","Nama","Posisi","Alamat","No HP","Gaji", "Jam","Tunjangan","Pajak","Total"};
    
    JLabel lTitle = new JLabel("APLIKASI PERHITUNGAN GAJI PT. VETERAN JAVA");
    JButton btnHome = new JButton("Home");
    JButton btnAdmin = new JButton("ADMIN");
    JButton btnGaji = new JButton("Gaji");
    JButton btnData = new JButton("Data");
    JButton btnPetunjuk = new JButton("Petunjuk");
    
    public View_Data(){
        setTitle("");
	setSize(700,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
	setLayout(null);
        add(btnHome);
        btnHome.setBounds(60,60,100,60);
        add(btnAdmin);
        btnAdmin.setBounds(550,60,100,60);
        add(btnGaji);
        btnGaji.setBounds(60,140,100,60);
        add(btnData);
        btnData.setBounds(60,220,100,60);
        add(btnPetunjuk);
        btnPetunjuk.setBounds(60,300,100,60);
        add(scrollPane);
        scrollPane.setBounds(20,270,650,180);
        tableModel = new DefaultTableModel(namaKolom,0);
        tabel = new JTable (tableModel);
        scrollPane = new JScrollPane(tabel);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        setVisible(true);
        
        btnHome.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                Responsi responsi = new Responsi();
            }
        });
        btnGaji.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                MVC mvc = new MVC();
                mvc.Gaji();
            }
        });
        
        btnData.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                MVC mvc = new MVC();
                mvc.Data();
            }
        });
        
        btnAdmin.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                Login_Admin login = new Login_Admin();
            }
        });
    }
}
