/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

/**
 *
 * @author ASUS
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
public class View_Pegawai extends JFrame {
    JLabel lTitle = new JLabel("APLIKASI PERHITUNGAN GAJI PT. VETERAN JAVA");
    JLabel lID = new JLabel(" ID Pegawai : ");
    JTextField tfID = new JTextField();
    JLabel lNama = new JLabel(" Nama : ");
    JTextField tfNama = new JTextField();
    JLabel lPosisi = new JLabel(" Posisi : ");
    String[] namaPosisi =
            {"","Direktur","Manager","Programmer","Marketing","Surveyor"};
    JComboBox cmbPosisi = new JComboBox(namaPosisi);
    JLabel lAlamat = new JLabel (" Alamat : ");
    JTextField tfAlamat = new JTextField();
    JLabel lNomer = new JLabel(" No HP : ");
    JTextField tfNomer = new JTextField();
    JLabel lGaji = new JLabel(" Gaji Pokok : ");
    JTextField tfGaji = new JTextField();
    JLabel lJam = new JLabel(" Jam Lembur : ");
    JTextField tfJam = new JTextField();
    JLabel lTunjangan = new JLabel(" Tunjangan : ");
    JTextField tfTunjangan = new JTextField();
    JLabel lPajak = new JLabel(" Pajak : ");
    JTextField tfPajak = new JTextField();
    JLabel lTotal = new JLabel(" Total Gaji : ");
    JTextField tfTotal = new JTextField();
    JButton btnHome = new JButton("Home");
    JButton btnAdmin = new JButton("ADMIN");
    JButton btnGaji = new JButton("Gaji");
    JButton btnData = new JButton("Data");
    JButton btnPetunjuk = new JButton("Petunjuk");
    JButton btnHitung = new JButton("Hitung");
    JButton btnSimpan = new JButton("Simpan");
    
    public View_Pegawai(){
        setTitle("");
	setSize(700,500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
	setLayout(null);
        
        add(lTitle);
        lTitle.setBounds(200,100,500,670);
        add(lID);
        lID.setBounds(200,60,100,20);
        add(tfID);
        tfID.setBounds(340,60,100,20);
        add(lNama);
        lNama.setBounds(200,90,100,20);
        add(tfNama);
        tfNama.setBounds(340,90,150,20);
        add(lPosisi);
        lPosisi.setBounds(200,120,100,20);
        add(cmbPosisi);
        cmbPosisi.setBounds(340,120,100,20);
        add(lAlamat);
        lAlamat.setBounds(200,150,100,20);
        add(tfAlamat);
        tfAlamat.setBounds(340,150,200,20);
        add(lNomer);
        lNomer.setBounds(200,180,100,20);
        add(tfNomer);
        tfNomer.setBounds(340,180,100,20);
        add(lGaji);
        lGaji.setBounds(200,210,100,20);
        add(tfGaji);
        tfGaji.setBounds(340,210,100,20);
        add(lJam);
        lJam.setBounds(200,240,100,20);
        add(tfJam);
        tfJam.setBounds(340,240,100,20);
        add(lTunjangan);
        lTunjangan.setBounds(200,270,100,20);
        add(tfTunjangan);
        tfTunjangan.setBounds(340,270,100,20);
        add(lPajak);
        lPajak.setBounds(200,300,100,20);
        add(tfPajak);
        tfPajak.setBounds(340,300,100,20);
        add(lTotal);
        lTotal.setBounds(200,330,100,20);
        add(tfTotal);
        tfTotal.setBounds(340,330,100,20);
        add(btnHome);
        btnHome.setBounds(60,60,100,60);
        add(btnAdmin);
        btnAdmin.setBounds(550,60,100,60);
        add(btnGaji);
        btnGaji.setBounds(60,140,100,60);
        add(btnData);
        btnData.setBounds(60,220,100,60);
        add(btnPetunjuk);
        btnPetunjuk.setBounds(60,300,100,60);
        add(btnHitung);
        btnHitung.setBounds(550,220,100,60);
        add(btnSimpan);
        btnSimpan.setBounds(550,300,100,60);
        setVisible(true);
        
        btnHome.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                Responsi responsi = new Responsi();
            }
        });
        btnGaji.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                MVC mvc = new MVC();
                mvc.Gaji();
            }
        });
        
        btnData.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                MVC mvc = new MVC();
                mvc.Data();
            }
        });
        
        btnAdmin.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                Login_Admin login = new Login_Admin();
            }
        });
        
    }
    
    public String getID(){
        return tfID.getText();
    }
    public String getNama(){
        return tfNama.getText();
    }
    public String getPosisi(){
        return cmbPosisi.getSelectedItem().toString();
    }
    public String getAlamat(){
        return tfAlamat.getText();
    }
    public String getNo(){
        return tfNomer.getText();
    }
    public String getGaji(){
        return tfGaji.getText();
    }
    public String getJam(){
        return tfJam.getText();
    }
    public String getTunjangan(){
        return tfTunjangan.getText();
    }
    public String getPajak(){
        return tfPajak.getText();
    }
    public String getTotal(){
        return tfTotal.getText();
    }
}
