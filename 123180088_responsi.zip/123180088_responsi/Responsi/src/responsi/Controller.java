/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

/**
 *
 * @author ASUS
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
public class Controller {
    View_Pegawai viewPegawai = new View_Pegawai();
    Model model = new Model();
    
    public Controller(View_Pegawai viewPegawai, Model model){
        this.viewPegawai = viewPegawai;
        this.model = model;
        
        
        viewPegawai.btnSimpan.addActionListener((ActionEvent e)-> {
            if(viewPegawai.getID().equals("")||viewPegawai.getNama().equals("")||viewPegawai.getPosisi().equals("")||viewPegawai.getNo().equals("")||viewPegawai.getGaji().equals("")||viewPegawai.getJam().equals("")||viewPegawai.getTunjangan().equals("")||viewPegawai.getPajak().equals("")||viewPegawai.getTotal().equals("")){
                JOptionPane.showMessageDialog(null, "Field Tidak Boleh Kosong");
            }
            else{
                String id_pegawai = viewPegawai.getID();
                String nama = viewPegawai.getNama();
                String posisi = viewPegawai.getPosisi();
                String alamat = viewPegawai.getAlamat();
                String no_hp = viewPegawai.getNo();
                String gaji = viewPegawai.getGaji();
                String jam = viewPegawai.getJam();
                String tunjangan = viewPegawai.getTunjangan();
                String pajak = viewPegawai.getPajak();
                String total = viewPegawai.getTotal();
                model.insertPegawai(id_pegawai, nama, posisi, alamat, no_hp, gaji, jam, tunjangan, pajak, total);
                
                
            }
        });
        
    
 }
}
   