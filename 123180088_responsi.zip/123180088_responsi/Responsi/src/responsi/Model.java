/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

/**
 *
 * @author ASUS
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
public class Model {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/responsipbo";
    static final String USER = "root";
    static final String PASS = "";
    
    Connection koneksi;
    Statement statement;
    
    public Model(){
        try{
            Class.forName(JDBC_DRIVER);
            koneksi = (Connection) DriverManager.getConnection(DB_URL,USER,PASS);
            System.out.println("Koneksi Berhasil");
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            System.out.println("Koneksi Gagal");
        }
    }
    
    public void insertPegawai(String id_pegawai, String nama, String posisi , String alamat, String no_hp, String gaji, String jam, String tunjangan, String pajak, String total ){
            try {
                String query = " INSERT INTO `pegawai`(`id_pegawai`,`nama`,`posisi`,`alamat`,`no_hp`,`gaji`,`jam`,`tunjangan`,`pajak`,`total`) VALUES ('"+id_pegawai+"','"+nama+"','"+posisi+"','"+alamat+"','"+no_hp+"','"+gaji+"','"+jam+"','"+tunjangan+"','"+pajak+"','"+total+"')";
                statement = (Statement) koneksi.createStatement(); 
                statement.executeUpdate(query);
                System.out.println("Berhasil Ditambahkan");
                JOptionPane.showMessageDialog(null,"Data Berhasil Ditambah");  
            }
            catch(Exception sql){
                System.out.println(sql.getMessage());
                JOptionPane.showMessageDialog(null, sql.getMessage());
            }
        }
    
    public String[][] readPegawai(){
            try{
                int jmlPegawai = 0;
                String pegawai[][] = new String[getBanyakPegawai()][10];
                String query = "SELECT * FROM `pegawai`";
                ResultSet resultSet = statement.executeQuery(query);
                while (resultSet.next()) {
                    pegawai[jmlPegawai][0] = resultSet.getString("id_pegawai");
                    pegawai[jmlPegawai][1] = resultSet.getString("nama");
                    pegawai[jmlPegawai][2] = resultSet.getString("posisi");
                    pegawai[jmlPegawai][3] = resultSet.getString("alamat");
                    pegawai[jmlPegawai][4] = resultSet.getString("no_hp");
                    pegawai[jmlPegawai][5] = resultSet.getString("gaji");
                    pegawai[jmlPegawai][6] = resultSet.getString("jam");
                    pegawai[jmlPegawai][7] = resultSet.getString("tunjangan");
                    pegawai[jmlPegawai][8] = resultSet.getString("pajak");
                    pegawai[jmlPegawai][9] = resultSet.getString("total");
                    jmlPegawai++;
                } return pegawai;
            }
            catch(SQLException e) {
                System.out.println(e.getMessage());
                System.out.println("SQL Error");
                return null;
            }
        }
    
    public int getBanyakPegawai(){
            int jmlPegawai = 0;
            try{
                statement = koneksi.createStatement();
                String query = "SELECT * FROM `pegawai`";
                ResultSet resultSet =  statement.executeQuery(query);
                while(resultSet.next()){
                    jmlPegawai++;
                } return jmlPegawai;
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
                System.out.println("SQL Error");
                return 0;
            }
        }
    
}
